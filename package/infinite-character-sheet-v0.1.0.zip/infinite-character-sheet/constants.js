export const MODULE_ID = "infinite-character-sheet";
